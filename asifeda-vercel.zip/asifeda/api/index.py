from flask import Flask, request, jsonify
import anthropic
import os

app = Flask(__name__)

# ── CORS (allow your frontend domain) ────────────────────────────────────────
@app.after_request
def add_cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "POST, OPTIONS"
    return response

@app.route("/api/chat", methods=["OPTIONS", "POST"])
def chat():
    if request.method == "OPTIONS":
        return jsonify({}), 200

    data = request.get_json()
    messages  = data.get("messages", [])
    system    = data.get("system", "You are AsifEdA AI — an expert tutor for Indian competitive exams including UPSC, JKSSB, NDA, SSC, Banking, JKPSC. Give clear, structured, exam-focused answers.")
    max_tokens = data.get("max_tokens", 1000)

    try:
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=max_tokens,
            system=system,
            messages=messages,
        )
        return jsonify({"content": response.content[0].text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "app": "AsifEdA API"})


# Local dev entry point
if __name__ == "__main__":
    app.run(debug=True, port=5000)
