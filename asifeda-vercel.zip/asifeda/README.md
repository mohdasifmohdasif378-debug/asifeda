# AsifEdA — Deployment Guide
**Creator: Muhammad Asif | Powered by Claude AI**

---

## Project Structure

```
asifeda/
├── api/
│   └── index.py        ← Flask backend (runs on Vercel)
├── public/
│   └── index.html      ← Your full frontend
├── requirements.txt    ← Python packages
├── vercel.json         ← Vercel routing config
└── .env.example        ← API key template
```

---

## Step 1 — Get Your Anthropic API Key

1. Go to https://console.anthropic.com
2. Sign up / Log in
3. Click **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)

---

## Step 2 — Deploy to Vercel (Free)

### Option A — Vercel Dashboard (Easiest, No terminal needed)

1. Go to https://github.com and create a **new repository** (e.g. `asifeda`)
2. Upload all these files to the repository
3. Go to https://vercel.com → **Add New Project**
4. Import your GitHub repository
5. Before clicking Deploy, go to **Environment Variables** and add:
   - Key: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-your-actual-key-here`
6. Click **Deploy** ✅

Your app will be live at: `https://your-project.vercel.app`

### Option B — Vercel CLI (Terminal)

```bash
# Install Vercel CLI
npm install -g vercel

# Go into project folder
cd asifeda

# Deploy
vercel

# Set your API key
vercel env add ANTHROPIC_API_KEY
# Paste your key when prompted

# Redeploy with the key
vercel --prod
```

---

## Step 3 — Test It

After deployment, visit:
- `https://your-project.vercel.app` → Full app
- `https://your-project.vercel.app/api/health` → Should return `{"status":"ok"}`

---

## Local Development (Optional)

```bash
# Install dependencies
pip install -r requirements.txt

# Create .env file with your key
cp .env.example .env
# Edit .env and paste your real API key

# Run locally
python api/index.py
# Open http://localhost:5000
```

---

## Cost Estimate

| Usage | Approx Cost |
|-------|-------------|
| 100 questions/day | ~$0.05/day |
| 1000 questions/day | ~$0.50/day |
| Heavy usage | ~$2–5/day |

Anthropic gives **$5 free credits** on sign-up — enough for thousands of questions.

---

## Important Notes

- ✅ API key is **never exposed** to users — it stays on the server
- ✅ Vercel free tier supports this fully
- ✅ Works on mobile browsers too
- ⚠️ Do NOT put your API key inside `index.html`
- ⚠️ Do NOT commit `.env` to GitHub (add it to `.gitignore`)

---

**Built by Muhammad Asif | AsifEdA Heavy-Duty AI Edition**
